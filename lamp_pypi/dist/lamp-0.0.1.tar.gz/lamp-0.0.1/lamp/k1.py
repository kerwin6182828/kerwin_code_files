class K1():
    def __init__(self):
        self.name = "kerwin"
        self.age = 24
    def call_name(self):
        print(self.name)



if __name__ == "__main__":
    x = K1()
    x.call_name()
