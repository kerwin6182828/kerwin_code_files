import time


print("hey! it's me! your friend kerwin")



def foo():
    print(time.ctime())

def bar(x):
    return x**2

